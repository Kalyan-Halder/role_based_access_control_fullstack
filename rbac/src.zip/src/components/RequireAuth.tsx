import { AuthContext } from "../context/AuthContext";
import { useRouter } from "next/router";
import { useContext, useEffect } from "react";

export default function RequireAuth({ children }: { children: React.ReactNode }) {
  const { auth } = useContext(AuthContext);
  const router = useRouter();

  useEffect(() => {
    if (!auth) router.replace("/login");
  }, [auth, router]);

  if (!auth) return <div className="p-6">Checking login...</div>;
  return <>{children}</>;
}
