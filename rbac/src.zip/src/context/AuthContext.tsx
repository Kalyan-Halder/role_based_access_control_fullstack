import React, { createContext, useEffect, useState } from "react";
import { AuthUser, clearAuthStorage, getAuthFromStorage, saveAuthToStorage } from "../lib/auth";

type AuthState = { token: string; user: AuthUser } | null;

export const AuthContext = createContext<{
  auth: AuthState;
  setAuth: (a: AuthState) => void;
  logout: () => void;
}>({
  auth: null,
  setAuth: () => {},
  logout: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [auth, setAuthState] = useState<AuthState>(null);

  useEffect(() => {
    const stored = getAuthFromStorage();
    if (stored) setAuthState(stored);
  }, []);

  function setAuth(a: AuthState) {
    setAuthState(a);
    if (a) saveAuthToStorage(a.token, a.user);
    else clearAuthStorage();
  }

  function logout() {
    setAuth(null);
  }

  return (
    <AuthContext.Provider value={{ auth, setAuth, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
